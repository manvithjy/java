package com.dao;

 

 

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

 

 


@Configuration
public class JavaConfigurationClass {

 

    @Bean(name={"ds"})
    public DriverManagerDataSource getDataSource() {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        ds.setUrl("jdbc:sqlserver://localhost;databaseName=Spring;instanceName=SQLEXPRESS");
        ds.setUsername("sa");
        ds.setPassword("password_123");
        return ds;    
    }

 

    @Bean(name={"jdbcTemp"})
    public JdbcTemplate getTemplate() {
        JdbcTemplate jbcTemplate = new JdbcTemplate();
        jbcTemplate.setDataSource(getDataSource());
        return jbcTemplate;
    }

 

    @Bean(name={"pDao"})
    public ProductDao getProductDao() {
        ProductDaoImpl pDao = new ProductDaoImpl();
        pDao.setJdbcTemplate(getTemplate());
        return pDao;
    }

 

 


}